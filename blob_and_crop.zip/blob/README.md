call python main.py, and enter the filepath of the image you want e.g "grid/a.jpg" or "out_of_frame/a.jpg"

then you will get 2 images, a blob detection and then the cropped image. i didnt make it so that it runs blob on the cropped, but you just have to call it 
